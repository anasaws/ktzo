Ktizo Application :
            Python 3.10


Installation :
            pip install fastapi
        


Run the development server:

           uvicorn main:app --reload


Open http://127.0.0.1:8000/docs  with your browser to see the result.







